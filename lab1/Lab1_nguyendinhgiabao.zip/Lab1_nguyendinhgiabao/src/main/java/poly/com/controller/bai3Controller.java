package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
@WebServlet("/bai3")
public class bai3Controller extends HttpServlet 
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	
	// Lấy các thông tin từ request
    String url = req.getRequestURL().toString();
    String uri = req.getRequestURI();
    String queryString = req.getQueryString();
    String servletPath = req.getServletPath();
    String contextPath = req.getContextPath();
    String pathInfo = req.getPathInfo();
    String method = req.getMethod();
    
    // Xuất thông tin ra trình duyệt
    resp.getWriter().println("<h2>URL: " + url + "</h2>");
    resp.getWriter().println("<h2>URI: " + uri + "</h2>");
    resp.getWriter().println("<h2>QueryString: " + queryString + "</h2>");
    resp.getWriter().println("<h2>ServletPath: " + servletPath + "</h2>");
    resp.getWriter().println("<h2>ContextPath: " + contextPath+ "</h2>");
    resp.getWriter().println("<h2>PathInfo: " + pathInfo + "</h2>");
    resp.getWriter().println("<h2>Method: " + method + "</h2>");
    
}
}
